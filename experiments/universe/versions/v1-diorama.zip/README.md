# Universe — prototype local isolé

Cette expérience ajoute uniquement `/universe` dans un serveur de développement dédié. Elle conserve l'accueil de chantier, les redirections temporaires et tous les fichiers du site existant. Elle ne change aucune commande de production ni configuration de déploiement.

## Lancer

Depuis la racine du dépôt, avec **Node.js 22 ou ultérieur** :

```sh
node experiments/universe/preview.mjs
```

Ouvrir [le prototype local](http://127.0.0.1:4324/universe). Le serveur écoute uniquement sur `127.0.0.1`. Un autre port peut être fourni en argument : `node experiments/universe/preview.mjs 4326`.

Le serveur habituel peut continuer à fonctionner sur `4321`. L'accueil du serveur du prototype affiche lui aussi la page de chantier existante. Les anciennes routes et les URL inconnues conservent leurs redirections `302` vers `/`.

## Isolation et retrait

- La configuration principale `astro.config.mjs` ne référence jamais cette expérience.
- La configuration alternative importe la configuration principale et injecte une seule route pendant la commande `dev`.
- Les commandes `build` et `preview` avec la configuration alternative sont explicitement refusées.
- Les composants, shaders, styles et ressources propres à l'expérience restent dans ce dossier. Les ressources sont importées depuis le code, sans ajout au dossier public du site.
- Aucun lien vers `/universe` n'est ajouté à l'accueil, au sitemap ou au menu du site.
- Le build de maintenance ordinaire continue à répondre `302` pour `/universe`, comme pour les autres URL inconnues. Aucun script ou modèle du prototype n'est inclus dans son résultat.

Pour retirer le prototype, arrêter son serveur et supprimer uniquement `experiments/universe`. Le cache facultatif `node_modules/.astro-universe` peut aussi être retiré. Aucun changement inverse n'est nécessaire dans le site existant.

## Vérifications

Les tests sont séparés des tests existants. Ils utilisent exclusivement les modules standard de Node.

```sh
# Empreintes SHA-256 de 281 fichiers protégés et garde de la configuration locale
node --test experiments/universe/tests/isolation.test.mjs

# Serveurs de développement actifs sur 4321 et 4324
node --test experiments/universe/tests/preview-routing.test.mjs

# Contrôle TypeScript/Astro limité au prototype
node node_modules/astro/astro.js check --tsconfig experiments/universe/tsconfig.json

# Build habituel, puis contrôle de son isolation (serveur temporaire sur port libre)
node scripts/build.mjs
node --test experiments/universe/tests/production-isolation.test.mjs
node --test tests/maintenance-routing.test.mjs
```

`MAINTENANCE_PREVIEW_URL` et `UNIVERSE_PREVIEW_URL` permettent de changer les adresses utilisées par les tests. L'instantané `tests/protected-files.snapshot.json` enregistre les octets du site au début du prototype ; il vérifie l'absence de modification dans `src`, `public`, `maintenance`, les scripts de build et les fichiers de déploiement. Il ne doit pas être régénéré pour masquer une modification.

### Scénarios navigateur

Avec le serveur du prototype actif :

```sh
node experiments/universe/tests/browser-harness.mjs
```

Le proxy QA est accessible sur `http://127.0.0.1:4325/universe?scenario=…` :

| Scénario | Vérification |
| --- | --- |
| `reduced` | Préférence de mouvement réduit, contrôles toujours utilisables |
| `webgl-disabled` | Scène de remplacement sans contexte WebGL |
| `no-js` | Contenu et scène de remplacement sans JavaScript |
| `context-loss` | Bouton local simulant une perte de contexte WebGL |
| `background` | Bouton local simulant un onglet masqué, puis sa réouverture |

Ces simulations concernent exclusivement ce proxy local. La page réelle ne charge aucun code du banc de test. Pour une évaluation de performance complète, compléter les mesures locales par un appareil mobile physique ; l'émulation de taille de fenêtre ne reproduit pas son GPU.
